import ShielddSecurity.TransferBlstArmInverseFactors01
set_option maxHeartbeats 200000
set_option maxRecDepth 4096
set_option autoImplicit false
namespace ShielddSecurity.TransferBlstArmInverseApproxLow01
open TransferScalarWordPrimitives01 (packWords)
open TransferScalarSerializationRange01 (radix64)
open TransferBlstArmInverseFactors01
  (sourceFactorInitial sourceFactorWalk original_initialized_factor_walk_derives_exact_scaled_input_rows)

/-! Exact low31 interpretation of the locked BFXIL approximation. Arbitrary
actual high-window words retain the original low word. The resulting factor
rows divide the entire original input exactly by 2^31. High-window selection,
approximation error/progress, signed word multiplication and ISA remain open. -/

def sourceApproxLow31 (high low : UInt64) : Nat :=
  high.toNat/2147483648*2147483648+low.toNat%2147483648

theorem original_approximation_replacement_retains_all_31_low_bits (high low : UInt64) :
    sourceApproxLow31 high low%2147483648=low.toNat%2147483648 := by
  unfold sourceApproxLow31
  omega

theorem original_full_input_and_low31_approximation_have_an_exact_signed_radix_difference
    (high low : UInt64) (rest : List UInt64) :
    ∃ difference : Int, (packWords (low::rest):Int)=
      (sourceApproxLow31 high low:Int)+2147483648*difference := by
  let difference : Int := ((low.toNat/2147483648:Nat):Int)+
    8589934592*(packWords rest:Int)-((high.toNat/2147483648:Nat):Int)
  refine ⟨difference,?_⟩
  have decomposition : (low.toNat:Int)=((low.toNat%2147483648:Nat):Int)+
      2147483648*((low.toNat/2147483648:Nat):Int) := by
    exact_mod_cast (Nat.mod_add_div low.toNat 2147483648).symm
  rw [packWords,sourceApproxLow31]
  push_cast
  change (low.toNat:Int)+18446744073709551616*(packWords rest:Int)=
    ((high.toNat/2147483648:Nat):Int)*2147483648+((low.toNat%2147483648:Nat):Int)+2147483648*difference
  dsimp only [difference]
  rw [decomposition]
  ring

theorem original_low31_approximation_preserves_oddness_of_the_original_low_word
    (high low : UInt64) (odd : low.toNat%2=1) :
    sourceApproxLow31 high low%2=1 := by
  unfold sourceApproxLow31
  omega

theorem original_31_factor_rows_divide_both_entire_inputs_without_losing_low_bits
    (highA lowA highB lowB : UInt64) (restA restB : List UInt64) (oddB : lowB.toNat%2=1) :
    let factors := sourceFactorWalk 31 (sourceFactorInitial
      (sourceApproxLow31 highA lowA) (sourceApproxLow31 highB lowB));
    (∃ quotient : Int, factors.f0*(packWords (lowA::restA):Int)+
      factors.g0*(packWords (lowB::restB):Int)=2147483648*quotient) ∧
    (∃ quotient : Int, factors.f1*(packWords (lowA::restA):Int)+
      factors.g1*(packWords (lowB::restB):Int)=2147483648*quotient) := by
  dsimp only
  rcases original_full_input_and_low31_approximation_have_an_exact_signed_radix_difference highA lowA restA with ⟨deltaA,inputA⟩
  rcases original_full_input_and_low31_approximation_have_an_exact_signed_radix_difference highB lowB restB with ⟨deltaB,inputB⟩
  have tracked := original_initialized_factor_walk_derives_exact_scaled_input_rows 31
    (sourceApproxLow31 highA lowA) (sourceApproxLow31 highB lowB)
    (original_low31_approximation_preserves_oddness_of_the_original_low_word highB lowB oddB)
  let factors := sourceFactorWalk 31 (sourceFactorInitial
    (sourceApproxLow31 highA lowA) (sourceApproxLow31 highB lowB))
  have first : factors.f0*(sourceApproxLow31 highA lowA:Int)+
      factors.g0*(sourceApproxLow31 highB lowB:Int)=2147483648*(factors.a:Int) := tracked.1.symm
  have second : factors.f1*(sourceApproxLow31 highA lowA:Int)+
      factors.g1*(sourceApproxLow31 highB lowB:Int)=2147483648*(factors.b:Int) := tracked.2.symm
  constructor
  · refine ⟨(factors.a:Int)+factors.f0*deltaA+factors.g0*deltaB,?_⟩
    rw [inputA,inputB]
    calc
      _ = (factors.f0*(sourceApproxLow31 highA lowA:Int)+factors.g0*(sourceApproxLow31 highB lowB:Int))+
          2147483648*(factors.f0*deltaA+factors.g0*deltaB) := by ring
      _ = _ := by rw [first]; ring
  · refine ⟨(factors.b:Int)+factors.f1*deltaA+factors.g1*deltaB,?_⟩
    rw [inputA,inputB]
    calc
      _ = (factors.f1*(sourceApproxLow31 highA lowA:Int)+factors.g1*(sourceApproxLow31 highB lowB:Int))+
          2147483648*(factors.f1*deltaA+factors.g1*deltaB) := by ring
      _ = _ := by rw [second]; ring

set_option pp.all true in
#check @sourceApproxLow31
#print axioms sourceApproxLow31
set_option pp.all true in
#check @original_approximation_replacement_retains_all_31_low_bits
#print axioms original_approximation_replacement_retains_all_31_low_bits
set_option pp.all true in
#check @original_full_input_and_low31_approximation_have_an_exact_signed_radix_difference
#print axioms original_full_input_and_low31_approximation_have_an_exact_signed_radix_difference
set_option pp.all true in
#check @original_low31_approximation_preserves_oddness_of_the_original_low_word
#print axioms original_low31_approximation_preserves_oddness_of_the_original_low_word
set_option pp.all true in
#check @original_31_factor_rows_divide_both_entire_inputs_without_losing_low_bits
#print axioms original_31_factor_rows_divide_both_entire_inputs_without_losing_low_bits
end ShielddSecurity.TransferBlstArmInverseApproxLow01
