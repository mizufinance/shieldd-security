-- GENERATED from the exact parent candidate by generate-field-certificate-tree-20261009-01.py.
import ShielddSecurity.LucasCertificate
import ShielddSecurity.FieldPrimeNode01
import ShielddSecurity.FieldPrimeNode02

set_option maxHeartbeats 300000
set_option maxRecDepth 4096

namespace ShielddSecurity.FieldPrimeNode14
open LucasCertificate

def certificate : Certificate := ⟨73, 5, [⟨2, 36, 72⟩, ⟨2, 36, 72⟩, ⟨2, 36, 72⟩, ⟨3, 24, 8⟩, ⟨3, 24, 8⟩]⟩

theorem checked : certificate.check = true := by decide +kernel

theorem prime : Nat.Prime 73 := by
  change Nat.Prime certificate.n
  apply certificate_sound certificate _ checked
  simp [certificate, FieldPrimeNode01.prime, FieldPrimeNode02.prime]

end ShielddSecurity.FieldPrimeNode14

set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode14.certificate
#print axioms ShielddSecurity.FieldPrimeNode14.certificate
set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode14.checked
#print axioms ShielddSecurity.FieldPrimeNode14.checked
set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode14.prime
#print axioms ShielddSecurity.FieldPrimeNode14.prime
