-- GENERATED from the exact parent candidate by generate-field-certificate-tree-20261009-01.py.
import ShielddSecurity.LucasCertificate
import ShielddSecurity.FieldPrimeNode01
import ShielddSecurity.FieldPrimeNode18

set_option maxHeartbeats 300000
set_option maxRecDepth 4096

namespace ShielddSecurity.FieldPrimeNode19
open LucasCertificate

def certificate : Certificate := ⟨359, 7, [⟨2, 179, 358⟩, ⟨179, 2, 49⟩]⟩

theorem checked : certificate.check = true := by decide +kernel

theorem prime : Nat.Prime 359 := by
  change Nat.Prime certificate.n
  apply certificate_sound certificate _ checked
  simp [certificate, FieldPrimeNode01.prime, FieldPrimeNode18.prime]

end ShielddSecurity.FieldPrimeNode19

set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode19.certificate
#print axioms ShielddSecurity.FieldPrimeNode19.certificate
set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode19.checked
#print axioms ShielddSecurity.FieldPrimeNode19.checked
set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode19.prime
#print axioms ShielddSecurity.FieldPrimeNode19.prime
