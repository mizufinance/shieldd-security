-- GENERATED from the exact parent candidate by generate-field-certificate-tree-20261009-01.py.
import ShielddSecurity.LucasCertificate
import ShielddSecurity.FieldPrimeNode01

set_option maxHeartbeats 300000
set_option maxRecDepth 4096

namespace ShielddSecurity.FieldPrimeNode03
open LucasCertificate

def certificate : Certificate := ⟨5, 2, [⟨2, 2, 4⟩, ⟨2, 2, 4⟩]⟩

theorem checked : certificate.check = true := by decide +kernel

theorem prime : Nat.Prime 5 := by
  change Nat.Prime certificate.n
  apply certificate_sound certificate _ checked
  simp [certificate, FieldPrimeNode01.prime]

end ShielddSecurity.FieldPrimeNode03

set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode03.certificate
#print axioms ShielddSecurity.FieldPrimeNode03.certificate
set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode03.checked
#print axioms ShielddSecurity.FieldPrimeNode03.checked
set_option pp.all true in
#check @ShielddSecurity.FieldPrimeNode03.prime
#print axioms ShielddSecurity.FieldPrimeNode03.prime
