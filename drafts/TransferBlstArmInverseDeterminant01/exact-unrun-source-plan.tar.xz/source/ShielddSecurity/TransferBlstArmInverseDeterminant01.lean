import ShielddSecurity.TransferBlstArmInverseFactors01
set_option maxHeartbeats 200000
set_option maxRecDepth 4096
set_option autoImplicit false
namespace ShielddSecurity.TransferBlstArmInverseDeterminant01
open TransferBlstArmInverseFactors01 (SourceFactors sourceFactorInitial sourceFactorStep sourceFactorWalk)

/-! Determinant of the original factor-row recurrence. Each update doubles
its absolute determinant; initialized arbitrary-count walks derive the exact
power of two. This is a source matrix invariant, not compiled execution or
approximate progress. Full-input batch GCD conservation is a later obligation. -/

def sourceFactorDeterminant (s : SourceFactors) : Int := s.f0*s.g1-s.f1*s.g0

theorem original_factor_row_step_doubles_the_entire_absolute_determinant (s : SourceFactors) :
    (sourceFactorDeterminant (sourceFactorStep s)).natAbs=2*(sourceFactorDeterminant s).natAbs := by
  rw [sourceFactorStep]
  split
  · change (s.f0*(2*s.g1)-(2*s.f1)*s.g0).natAbs=2*(sourceFactorDeterminant s).natAbs
    have identity : s.f0*(2*s.g1)-(2*s.f1)*s.g0=2*sourceFactorDeterminant s := by
      rw [sourceFactorDeterminant]; ring
    rw [identity, Int.natAbs_mul]
    rfl
  · split
    · change ((s.f0-s.f1)*(2*s.g1)-(2*s.f1)*(s.g0-s.g1)).natAbs=2*(sourceFactorDeterminant s).natAbs
      have identity : (s.f0-s.f1)*(2*s.g1)-(2*s.f1)*(s.g0-s.g1)=2*sourceFactorDeterminant s := by
        rw [sourceFactorDeterminant]; ring
      rw [identity, Int.natAbs_mul]
      rfl
    · change ((s.f1-s.f0)*(2*s.g0)-(2*s.f0)*(s.g1-s.g0)).natAbs=2*(sourceFactorDeterminant s).natAbs
      have identity : (s.f1-s.f0)*(2*s.g0)-(2*s.f0)*(s.g1-s.g0)= -2*sourceFactorDeterminant s := by
        rw [sourceFactorDeterminant]; ring
      rw [identity, Int.natAbs_mul]
      rfl

theorem symbolic_original_factor_row_walk_derives_the_entire_scaled_absolute_determinant
    (count : Nat) (s : SourceFactors) :
    (sourceFactorDeterminant (sourceFactorWalk count s)).natAbs=
      2^count*(sourceFactorDeterminant s).natAbs := by
  induction count generalizing s with
  | zero => simp only [sourceFactorWalk, pow_zero, one_mul]
  | succ count ih =>
      rw [sourceFactorWalk, ih, original_factor_row_step_doubles_the_entire_absolute_determinant, pow_succ]
      ring

theorem original_initialized_factor_rows_have_exact_absolute_determinant_power
    (count a b : Nat) :
    (sourceFactorDeterminant (sourceFactorWalk count (sourceFactorInitial a b))).natAbs=2^count := by
  rw [symbolic_original_factor_row_walk_derives_the_entire_scaled_absolute_determinant]
  have initial : (sourceFactorDeterminant (sourceFactorInitial a b)).natAbs=1 := by rfl
  rw [initial, mul_one]

theorem original_initialized_factor_determinant_is_exactly_a_signed_radix_power
    (count a b : Nat) :
    sourceFactorDeterminant (sourceFactorWalk count (sourceFactorInitial a b))=(2:Int)^count \/
    sourceFactorDeterminant (sourceFactorWalk count (sourceFactorInitial a b))= -((2:Int)^count) := by
  have absolute := original_initialized_factor_rows_have_exact_absolute_determinant_power count a b
  by_cases nonnegative : 0 <= sourceFactorDeterminant (sourceFactorWalk count (sourceFactorInitial a b))
  · left
    rw [Int.eq_natAbs_of_nonneg nonnegative, absolute]
    norm_cast
  · right
    have nonpositive : sourceFactorDeterminant (sourceFactorWalk count (sourceFactorInitial a b)) <= 0 := by omega
    rw [Int.eq_neg_natAbs_of_nonpos nonpositive, absolute]
    norm_cast

set_option pp.all true in
#check @sourceFactorDeterminant
#print axioms sourceFactorDeterminant
set_option pp.all true in
#check @original_factor_row_step_doubles_the_entire_absolute_determinant
#print axioms original_factor_row_step_doubles_the_entire_absolute_determinant
set_option pp.all true in
#check @symbolic_original_factor_row_walk_derives_the_entire_scaled_absolute_determinant
#print axioms symbolic_original_factor_row_walk_derives_the_entire_scaled_absolute_determinant
set_option pp.all true in
#check @original_initialized_factor_rows_have_exact_absolute_determinant_power
#print axioms original_initialized_factor_rows_have_exact_absolute_determinant_power
set_option pp.all true in
#check @original_initialized_factor_determinant_is_exactly_a_signed_radix_power
#print axioms original_initialized_factor_determinant_is_exactly_a_signed_radix_power
end ShielddSecurity.TransferBlstArmInverseDeterminant01
