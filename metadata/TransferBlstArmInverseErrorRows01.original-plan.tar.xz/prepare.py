from pathlib import Path
import argparse, hashlib, importlib.util, json, re, shutil
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--base',required=True);p.add_argument('--module',required=True);p.add_argument('--addon',action='append',default=[]);p.add_argument('--scope',required=True);a=p.parse_args()
D=Path(__file__).resolve().parent;R=D/a.root;B=D/a.base;M=a.module
def pin(path):
 path=Path(path);b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(path,obj):path.write_bytes((json.dumps(obj,indent=2,sort_keys=True)+'\n').encode())
assert not (R/'plan.json').exists()
R.mkdir(exist_ok=True);shutil.copyfile(__file__,R/'prepare.py');shutil.copyfile(B/'execute_bounded.py',R/'execute_bounded.py')
runner=R/'execute_bounded.py';assert pin(runner)['sha256']=='7237060ba9e0d0b98e93cfe5aceb86a4d7390e2af2471b43e39cf3750ebc642b'
spec=importlib.util.spec_from_file_location('auditor',runner);aud=importlib.util.module_from_spec(spec);spec.loader.exec_module(aud)
plan=json.loads((B/'plan.json').read_bytes());old=json.loads(Path(plan['owned_import_pool']['path']).read_bytes())
records=[(r['module'],r['source'],r['object'])for r in old['selected']];audits=dict(old['inherited_public_reports']);inputs=list(old['input_records'])
for root in [B]+[D/x for x in a.addon]:
 events=[json.loads(x)for x in(root/'events.jsonl').read_text().splitlines()]
 assert len(events)==2 and events[-1]['result']['status']=='passed',str(root)
 rp=json.loads((root/'plan.json').read_bytes());result=events[-1]['result'];target=rp['targets'][0]
 stdout=Path(result['stdout']['path']);assert pin(stdout)==result['stdout']
 reports=aud.audit(stdout.read_text(),target['audit_names']);assert reports==result['audits']
 if target['module'] in {x[0]for x in records}:
  oldrow=next(x for x in records if x[0]==target['module']);assert oldrow[1]==target['source'] and oldrow[2]==result['objects'][0]
  assert all(audits[k]==v for k,v in reports.items());continue
 assert set(audits).isdisjoint(reports);audits.update(reports);records.append((target['module'],target['source'],result['objects'][0]))
 inputs += [pin(x)for x in [root/'plan.json',root/'review.json',root/'events.jsonl',root/'execute_bounded.py',stdout]]+rp['pins']
by_name={name:(source,obj)for name,source,obj in records};seen=set()
def check_owned_closure(name,source):
 if name in seen:return
 seen.add(name)
 for dependency in re.findall(r'^import (.+)',aud.code_only(Path(source['path']).read_text()),re.M):
  if not dependency.startswith('ShielddSecurity.'):continue
  dependency=dependency.removeprefix('ShielddSecurity.')
  assert dependency in by_name,'Missing transitive owned import '+dependency+' from '+name
  check_owned_closure(dependency,by_name[dependency][0])
check_owned_closure(M,pin(R/'handwritten'/(M+'.lean')))
pool=D/(a.root+'-owned-floor');pool.mkdir();selected=[]
for name,source,obj in records:
 assert pin(source['path'])==source and pin(obj['path'])==obj
 copy=pool/'modules/ShielddSecurity'/(name+'.olean');copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj['path'],copy)
 assert pin(copy)['sha256']==obj['sha256'];selected.append({'module':name,'source':source,'object':obj,'copy':pin(copy)});inputs +=[source,obj]
inputs=list({json.dumps(x,sort_keys=True):x for x in inputs}.values())
composition={**old,'objects':len(records),'selected':selected,'input_records':inputs,'inherited_public_reports':audits,'charged_new_object_bytes':sum(x['copy']['bytes']for x in selected),'scope':a.scope}
cf=pool/'composition-review.json';dump(cf,composition)
hs=R/'handwritten'/(M+'.lean');raw=hs.read_text();assert '#check' not in raw
names=re.findall(r'^(?:def|abbrev|theorem|instance|local instance) (\w+)',raw,re.M);assert len(names)==len(set(names)) and names
assert not re.search(r'\b(?:sorry|admit|axiom)\b',aud.code_only(raw))
namespace='ShielddSecurity.'+M
raw=raw.replace('end '+namespace,'\n'.join('set_option pp.all true in\n#check @'+n+'\n#print axioms '+n for n in names)+'\nend '+namespace)
hs.write_bytes(raw.encode());ps=R/'project/ShielddSecurity'/hs.name;ps.parent.mkdir(parents=True);shutil.copyfile(hs,ps)
mapping={'scope':a.scope,'native_credit':0,'certification':False,'source':pin(hs),'qualified_predecessors':[pin(B/'plan.json')]+[pin(D/x/'plan.json')for x in a.addon],'private_origin_census':'Exact source-model operations and field projections only; compiler/native caller correspondence remains separate.'};mf=R/'source-mapping.json';dump(mf,mapping)
if 'Commonware' in M:
 runtime=Path('C:/src/shieldd-pr160-844389ee');ctx=R/'context';ctx.mkdir()
 paths=[runtime/'Cargo.lock',runtime/'third_party/commonware/cryptography/src/bls12381/primitives/group.rs',runtime/'crates/crypto/circuits/src/map.rs',runtime/'crates/crypto/primitives/src/map.rs']
 mapping['exact_runtime_sha']='844389ee069e1fb2e576708842d0b389b4d9a44a';mapping['runtime_sources']=[]
 for i,path in enumerate(paths):
  cp=ctx/(str(i)+'-'+path.name);shutil.copyfile(path,cp);inputs +=[pin(path),pin(cp)];mapping['runtime_sources'].append({'original':pin(path),'copy':pin(cp)})
 mapping['private_origin_census']={'input':'Explicit exact prime field/source-model domain; no blst private representation constructor theorem supplied','search':'Current residue checked before square and UInt32 increment; m refusal after increment modeled, successful finite traversal derived','correction':'Exact m-i-1 repeated-square recurrence, no chosen correction supplied','arithmetic':'Field interpretation only; blst exp/inv/mul/square and canonical encode origins remain distinct obligations','caller':'circuits map::to_prime and witness closures use Commonware Scalar::sqrt; SDK map uses distinct ff helper'}
 dump(mf,mapping)
if M.startswith('TransferJubjub'):
 binding=D/'transfer-jubjub-cofactor-binding-20261012-01';jc=json.loads((binding/'locked-source-context.json').read_bytes());original=Path(jc['source']['path'])
 assert {k:v for k,v in pin(original).items()if k!='path'}==jc['source']['identity']
 mapping['locked_jubjub_source_context']=jc;inputs +=[pin(binding/'locked-source-context.json'),pin(original)]+[pin(x)for x in sorted((binding/'context').rglob('*'))if x.is_file()]
 dump(mf,mapping)
if M.startswith('TransferBlst'):
 binding=D/('transfer-blst-cneg-source-binding-20261013-01' if M in ('TransferBlstArmCneg01','TransferBlstArmAdd01','TransferBlstArmSub01','TransferBlstArmFieldCodec01') else 'transfer-blst-montgomery-source-binding-20261012-01' if M.startswith('TransferBlstArm') or M.startswith('TransferBlstMontgomery') else 'transfer-blst-source-binding-20261012-01');bc=json.loads((binding/'locked-source-context.json').read_bytes())
 assert bc['archive_members_match_extracted_sources'] and bc['package']['version']=='0.3.17'
 mapping['locked_blst_source_context']=bc;inputs.append(pin(binding/'locked-source-context.json'))
 for row in bc['sources']:
  original=Path(row['original_path']);cp=binding/row['copy_path'];assert {k:v for k,v in pin(original).items()if k!='path'}==row['identity'] and original.read_bytes()==cp.read_bytes();inputs +=[pin(original),pin(cp)]
 dump(mf,mapping)
if M in ('TransferBlstArmCaller01','TransferBlstArmIdentity01','TransferBlstArmStage01','TransferBlstArmPending01','TransferBlstArmNullifierReader01','TransferBlstArmPublication01','TransferBlstArmSdkBridge01','TransferBlstArmFieldCodec01','TransferBlstArmStageReader01','TransferBlstArmRingCaller01','TransferBlstArmSqrtSearch01','TransferBlstArmSqrtWhile01','TransferBlstArmSqrtCaller01','TransferBlstArmRedc01','TransferBlstArmSqrtState01','TransferBlstArmSqrtIndices01','TransferBlstArmInverseTail01','TransferBlstArmSqrtObserved01','TransferBlstArmInverseFactors01','TransferBlstArmInverseSign01','TransferBlstArmInverseBounds01','TransferBlstArmInverseFirst01','TransferBlstArmInverseMask01','TransferBlstArmInverseSecond01','TransferBlstArmInversePipeline01','TransferBlstArmInverseNorm01','TransferBlstArmInverseSharp01','TransferBlstArmInversePack01','TransferBlstArmInverseProgress01','TransferBlstArmInverseApproxLow01','TransferBlstArmInversePackedWalk01','TransferBlstArmInverseApproxBits01','TransferBlstArmInverseApproxInput01','TransferBlstArmInverseApproxRows01','TransferBlstArmInverseApproxParity01','TransferBlstArmInverseBatchOdd01','TransferBlstArmInverseBatchBounds01','TransferBlstArmInverseBatchOddDiagnostic01','TransferBlstArmInverseAbsOdd01','TransferBlstArmInverseCoeffBounds01','TransferBlstArmInverseSignedWord01','TransferBlstArmInverseSignBit01','TransferBlstArmInverseSignMask01','TransferBlstArmInverseFactorMagnitude01','TransferBlstArmInverseExactGcd01','TransferBlstArmInverseDebiasWord01','TransferBlstArmInverseDeterminant01','TransferBlstArmInverseApproxError01','TransferBlstArmInverseErrorRows01','TransferBlstArmInversePrefixDiv01','TransferBlstArmInversePrefixError01'):
 runtime=Path('C:/src/shieldd-pr160-844389ee');ctx=R/'context';ctx.mkdir()
 paths=[runtime/'Cargo.lock',runtime/'third_party/commonware/cryptography/src/bls12381/primitives/group.rs',runtime/'crates/crypto/primitives/src/map.rs']
 if M in ('TransferBlstArmPending01','TransferBlstArmNullifierReader01','TransferBlstArmPublication01','TransferBlstArmSdkBridge01','TransferBlstArmFieldCodec01','TransferBlstArmStageReader01','TransferBlstArmRingCaller01','TransferBlstArmSqrtSearch01','TransferBlstArmSqrtWhile01','TransferBlstArmSqrtCaller01','TransferBlstArmRedc01','TransferBlstArmSqrtState01','TransferBlstArmSqrtIndices01','TransferBlstArmInverseTail01','TransferBlstArmSqrtObserved01','TransferBlstArmInverseFactors01','TransferBlstArmInverseSign01','TransferBlstArmInverseBounds01','TransferBlstArmInverseFirst01','TransferBlstArmInverseMask01','TransferBlstArmInverseSecond01','TransferBlstArmInversePipeline01','TransferBlstArmInverseNorm01','TransferBlstArmInverseSharp01','TransferBlstArmInversePack01','TransferBlstArmInverseProgress01','TransferBlstArmInverseApproxLow01','TransferBlstArmInversePackedWalk01','TransferBlstArmInverseApproxBits01','TransferBlstArmInverseApproxInput01','TransferBlstArmInverseApproxRows01','TransferBlstArmInverseApproxParity01','TransferBlstArmInverseBatchOdd01','TransferBlstArmInverseBatchBounds01','TransferBlstArmInverseBatchOddDiagnostic01','TransferBlstArmInverseAbsOdd01','TransferBlstArmInverseCoeffBounds01','TransferBlstArmInverseSignedWord01','TransferBlstArmInverseSignBit01','TransferBlstArmInverseSignMask01','TransferBlstArmInverseFactorMagnitude01','TransferBlstArmInverseExactGcd01','TransferBlstArmInverseDebiasWord01','TransferBlstArmInverseDeterminant01','TransferBlstArmInverseApproxError01','TransferBlstArmInverseErrorRows01','TransferBlstArmInversePrefixDiv01','TransferBlstArmInversePrefixError01'):
  paths += [runtime/'crates/core/component/sct/src/component/tree.rs',runtime/'crates/core/component/sct/src/nullifier.rs',runtime/'crates/crypto/circuits/src/encoding.rs',runtime/'crates/crypto/primitives/src/lib.rs']
 if M in ('TransferBlstArmRingCaller01','TransferBlstArmSqrtSearch01','TransferBlstArmSqrtWhile01','TransferBlstArmSqrtCaller01','TransferBlstArmRedc01','TransferBlstArmSqrtState01','TransferBlstArmSqrtIndices01','TransferBlstArmInverseTail01','TransferBlstArmSqrtObserved01','TransferBlstArmInverseFactors01','TransferBlstArmInverseSign01','TransferBlstArmInverseBounds01','TransferBlstArmInverseFirst01','TransferBlstArmInverseMask01','TransferBlstArmInverseSecond01','TransferBlstArmInversePipeline01','TransferBlstArmInverseNorm01','TransferBlstArmInverseSharp01','TransferBlstArmInversePack01','TransferBlstArmInverseProgress01','TransferBlstArmInverseApproxLow01','TransferBlstArmInversePackedWalk01','TransferBlstArmInverseApproxBits01','TransferBlstArmInverseApproxInput01','TransferBlstArmInverseApproxRows01','TransferBlstArmInverseApproxParity01','TransferBlstArmInverseBatchOdd01','TransferBlstArmInverseBatchBounds01','TransferBlstArmInverseBatchOddDiagnostic01','TransferBlstArmInverseAbsOdd01','TransferBlstArmInverseCoeffBounds01','TransferBlstArmInverseSignedWord01','TransferBlstArmInverseSignBit01','TransferBlstArmInverseSignMask01','TransferBlstArmInverseFactorMagnitude01','TransferBlstArmInverseExactGcd01','TransferBlstArmInverseDebiasWord01','TransferBlstArmInverseDeterminant01','TransferBlstArmInverseApproxError01','TransferBlstArmInverseErrorRows01','TransferBlstArmInversePrefixDiv01','TransferBlstArmInversePrefixError01'):paths += [runtime/'third_party/commonware/math/src/algebra.rs']
 mapping['exact_runtime_sha']='844389ee069e1fb2e576708842d0b389b4d9a44a';mapping['runtime_sources']=[]
 for i,path in enumerate(paths):
  cp=ctx/(str(i)+'-'+path.name);shutil.copyfile(path,cp);inputs +=[pin(path),pin(cp)];mapping['runtime_sources'].append({'original':pin(path),'copy':pin(cp)})
 mapping['caller_origin_obligations']=['Separate typed input/scalar/output allocations modeled; actual pointer separation and ABI remain open','ARM arithmetic conversion only; selected backend execution/compiler correspondence remains open','Raw input field meaning derived without desired output normalization premise; upstream constructor/arithmetic representation invariants remain open','Sign guard derived; selected field meaning does not prove native cneg implementation']
 if M in ('TransferBlstArmPending01','TransferBlstArmNullifierReader01','TransferBlstArmPublication01','TransferBlstArmSdkBridge01','TransferBlstArmFieldCodec01','TransferBlstArmStageReader01','TransferBlstArmRingCaller01','TransferBlstArmSqrtSearch01','TransferBlstArmSqrtWhile01','TransferBlstArmSqrtCaller01','TransferBlstArmRedc01','TransferBlstArmSqrtState01','TransferBlstArmSqrtIndices01','TransferBlstArmInverseTail01','TransferBlstArmSqrtObserved01','TransferBlstArmInverseFactors01','TransferBlstArmInverseSign01','TransferBlstArmInverseBounds01','TransferBlstArmInverseFirst01','TransferBlstArmInverseMask01','TransferBlstArmInverseSecond01','TransferBlstArmInversePipeline01','TransferBlstArmInverseNorm01','TransferBlstArmInverseSharp01','TransferBlstArmInversePack01','TransferBlstArmInverseProgress01','TransferBlstArmInverseApproxLow01','TransferBlstArmInversePackedWalk01','TransferBlstArmInverseApproxBits01','TransferBlstArmInverseApproxInput01','TransferBlstArmInverseApproxRows01','TransferBlstArmInverseApproxParity01','TransferBlstArmInverseBatchOdd01','TransferBlstArmInverseBatchBounds01','TransferBlstArmInverseBatchOddDiagnostic01','TransferBlstArmInverseAbsOdd01','TransferBlstArmInverseCoeffBounds01','TransferBlstArmInverseSignedWord01','TransferBlstArmInverseSignBit01','TransferBlstArmInverseSignMask01','TransferBlstArmInverseFactorMagnitude01','TransferBlstArmInverseExactGcd01','TransferBlstArmInverseDebiasWord01','TransferBlstArmInverseDeterminant01','TransferBlstArmInverseApproxError01','TransferBlstArmInverseErrorRows01','TransferBlstArmInversePrefixDiv01','TransferBlstArmInversePrefixError01'):
  mapping['caller_origin_obligations']=['SCT Nullifier wraps SDK jubjub::Fq; it uses reversed SDK little-endian bytes for Ord and original SDK words for Eq, not a direct blst comparator call','Qualified SDK/BLST source serialization bridges identify the mathematical key observations on the explicit canonical-word domain','Private SDK value producers, actual Rust collections/Any/Clone, pointer/ABI/compiler and async execution remain open','Durable lookup supplies an authenticated-key interface; returned source-model reader success derives full alignment and every original input observation']
 dump(mf,mapping)
 dump(R/'locked-source-context.json',{'scope':a.scope,'native_credit':0,'certification':False,'exact_runtime_sha':mapping['exact_runtime_sha'],'sources':mapping['runtime_sources'],'obligations':mapping['caller_origin_obligations']})
if M in ('TransferBlstArmInverseTail01','TransferBlstArmInverseFactors01','TransferBlstArmInverseSign01','TransferBlstArmInverseFirst01','TransferBlstArmInverseMask01','TransferBlstArmInverseSecond01','TransferBlstArmInversePipeline01','TransferBlstArmInverseNorm01','TransferBlstArmInverseSharp01','TransferBlstArmInversePack01','TransferBlstArmInverseProgress01','TransferBlstArmInverseApproxLow01','TransferBlstArmInversePackedWalk01','TransferBlstArmInverseApproxBits01','TransferBlstArmInverseApproxInput01','TransferBlstArmInverseApproxRows01','TransferBlstArmInverseApproxParity01','TransferBlstArmInverseBatchOdd01','TransferBlstArmInverseBatchBounds01','TransferBlstArmInverseBatchOddDiagnostic01','TransferBlstArmInverseAbsOdd01','TransferBlstArmInverseCoeffBounds01','TransferBlstArmInverseSignedWord01','TransferBlstArmInverseSignBit01','TransferBlstArmInverseSignMask01','TransferBlstArmInverseFactorMagnitude01','TransferBlstArmInverseExactGcd01','TransferBlstArmInverseDebiasWord01','TransferBlstArmInverseDeterminant01','TransferBlstArmInverseApproxError01','TransferBlstArmInverseErrorRows01','TransferBlstArmInversePrefixDiv01','TransferBlstArmInversePrefixError01'):
 binding=D/'transfer-blst-inverse-source-binding-20261013-01';ic=json.loads((binding/'locked-source-context.json').read_bytes())
 assert pin(ic['archive']['path'])==ic['archive'] and all(x['matches']for x in ic['sources'])
 inputs +=[pin(binding/'locked-source-context.json'),ic['archive']]
 copied=[]
 for row in ic['sources']:
  original=Path(row['original']['path']);prior=Path(row['copy']['path']);assert pin(original)==row['original'] and pin(prior)==row['copy'] and original.read_bytes()==prior.read_bytes()
  cp=R/'context/locked-inverse-source'/prior.relative_to(binding/'context');cp.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(prior,cp)
  inputs +=[pin(original),pin(prior),pin(cp)];copied.append({**row,'copy':pin(cp)})
 mapping['locked_inverse_source_context']={**ic,'sources':copied};dump(mf,mapping)
 lc=json.loads((R/'locked-source-context.json').read_bytes());lc['locked_inverse_source_context']=mapping['locked_inverse_source_context'];dump(R/'locked-source-context.json',lc)
plan['owned_import_pool']=pin(cf);plan['owned_imports']=[x['copy']for x in selected];plan['lean_path'][0:2]=[str(pool/'modules'),str(R/'project')]
plan['targets']=[{'module':M,'source':pin(ps),'predecessor_source':pin(hs),'imports':re.findall(r'^import (.+)',aud.code_only(raw),re.M),'audit_names':[namespace+'.'+n for n in names]}]
plan['pins']+=inputs+plan['owned_imports']+[pin(x)for x in [R/'prepare.py',runner,hs,ps,cf,mf]]
plan['pins']=list({json.dumps(x,sort_keys=True):x for x in plan['pins']}.values())
plan['artifact_policy']='Fresh handwritten symbolic module; no evidence refresh, source objects reused after exact source/object/audit checks.'
pf=R/'plan.json';pf.write_bytes((json.dumps(plan,sort_keys=True,separators=(',',':'))+'\n').encode())
review={'status':'SELF_REVIEWED_UNRUN','plan':pin(pf),'runner':pin(runner),'owned_floor':pin(cf),'fresh_audits':len(names),'inherited_audits':len(audits),'scope':a.scope,'arguments':vars(a),'native_credit':0,'certification':False};dump(R/'review.json',review)
assert sum(x.stat().st_size for x in R.rglob('*')if x.is_file())+6*8388608+1048576+262144<134217728
print(json.dumps(review))
