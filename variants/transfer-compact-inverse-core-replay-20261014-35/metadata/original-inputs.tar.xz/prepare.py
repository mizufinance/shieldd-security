"""Next eight fresh modules, importing only the qualified packing boundary."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import shutil

D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--root',default='transfer-compact-inverse-core-replay-20261014-03');p.add_argument('--base',default='transfer-packing-owner-replay-20261014-05');p.add_argument('--module',default='TransferBlstArmInverseFactors01');p.add_argument('--source-dir',default='compact-inverse-sources-20261014-02');args=p.parse_args()
R=(D/args.root).resolve();assert R.parent==D and not R.exists();R.mkdir()
B=D/args.base;base=json.loads((B/'plan.json').read_bytes())
events=[json.loads(x)for x in(B/'events.jsonl').read_text().splitlines()]
finished=[x for x in events if x['event']=='attempt_finished'];assert len(events)==2*len(base['targets']) and all(x['result']['status']=='passed'for x in finished)
spec=importlib.util.spec_from_file_location('guard',B/'execute_bounded.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def pin(path):
 with path.open('rb')as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':sha}
def dump(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
pool=R/'owned-floor';selected=[];inherited={};packing_expected=json.loads((B/'baseline-type-axiom-review.json').read_bytes())['expected_reports']
prior_pool=json.loads(Path(base['owned_import_pool']['path']).read_bytes())
for record in prior_pool['selected']:
 obj=record['copy'];assert g.digest(Path(obj['path']))==obj['sha256']
 copy=pool/'modules'/'ShielddSecurity'/(record['module']+'.olean');copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj['path'],copy)
 selected.append({'module':record['module'],'source':record['source'],'object':obj,'copy':pin(copy)})
inherited.update(prior_pool['inherited_public_reports'])
new_reports={}
for target,event in zip(base['targets'],finished):
 result=event['result'];assert g.audit(Path(result['stdout']['path']).read_text(encoding='utf-8'),target['audit_names'])==result['audits']
 inherited.update(result['audits']);new_reports.update(result['audits']);obj=next(x for x in result['objects']if x['path'].endswith('.olean'))
 assert g.digest(Path(obj['path']))==obj['sha256']
 copy=pool/'modules'/'ShielddSecurity'/(target['module']+'.olean');copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj['path'],copy)
 selected.append({'module':target['module'],'source':target['source'],'object':obj,'copy':pin(copy)})
assert new_reports==packing_expected
pool_path=pool/'composition-review.json';dump(pool_path,{'admission_ready':True,'kernel_credit':0,'selected':selected,'objects':len(selected),'inherited_public_reports':inherited,'input_records':[]})
old_plan=json.loads((D/'transfer-blst-arm-inverse-window-returned-20261014-03'/'plan.json').read_bytes())
old_composition=json.loads(Path(old_plan['owned_import_pool']['path']).read_bytes())
old_reports=dict(old_composition['inherited_public_reports'])
# The final original target is recorded in its own fresh events, not the import pool.
original_root=D/'transfer-blst-arm-inverse-window-returned-20261014-03'
original_events=[json.loads(x) for x in (original_root/'events.jsonl').read_text().splitlines()]
assert len(original_events)==2 and original_events[-1]['result']['status']=='passed'
original_result=original_events[-1]['result']; original_target=old_plan['targets'][0]
original_stdout=Path(original_result['stdout']['path'])
assert pin(original_stdout)==original_result['stdout']
assert g.audit(original_stdout.read_text(encoding='utf-8'),original_target['audit_names'])==original_result['audits']
assert old_reports.keys().isdisjoint(original_result['audits'])
old_reports.update(original_result['audits'])
original_qualifier=[pin(original_root/'plan.json'),pin(original_root/'events.jsonl'),pin(original_stdout)]
names=[args.module]
targets=[];expected={};roots={'Init'}
for module in names:
 source=D/args.source_dir/(module+'.lean');text=source.read_text(encoding='utf-8');ns=re.search(r'^namespace (\S+)',text,re.M)[1]
 declarations=re.findall(r'^(?:def|theorem|structure) (\w+)',g.code_only(text),re.M)
 # Existing Factors receipts audit its eight original public declarations;
 # the SourceFactors structure body is retained unchanged in the source.
 audited=[n for n in declarations if ns+'.'+n in old_reports];assert audited
 imports,implicit=g.header(text);assert implicit
 for dependency in imports:
  if dependency.startswith('ShielddSecurity.'):
   owner=dependency.removeprefix('ShielddSecurity.');assert owner in [x['module']for x in selected]+names[:names.index(module)],dependency
  else:roots.add(dependency)
 text=text.replace('end '+ns,'\n'.join('set_option pp.all true in\n#check @'+n+'\n#print axioms '+n for n in audited)+'\nend '+ns)
 handwritten=R/'handwritten'/source.name;project=R/'project'/'ShielddSecurity'/source.name
 handwritten.parent.mkdir(exist_ok=True);project.parent.mkdir(parents=True,exist_ok=True);handwritten.write_bytes(text.encode());shutil.copyfile(handwritten,project)
 audit_names=[ns+'.'+n for n in audited]
 targets.append({'module':module,'source':pin(project),'predecessor_source':pin(handwritten),'original_source':pin(source),'imports':imports,'audit_names':audit_names})
 expected.update({n:old_reports[n]for n in audit_names})
original_floor=json.loads(Path(old_plan['external_floor']['path']).read_bytes());external={}
def include(name):
 if name in external:return
 assert name in original_floor['modules'],name
 entry=original_floor['modules'][name];external[name]=entry
 for dep in entry['imports']:include(dep)
 if entry.get('implicit_Init'):include('Init')
for name in roots:include(name)
# Packing objects also depend on their exact external closure.
for name in json.loads((B/'external-floor.json').read_bytes())['modules']:include(name)
records={x['path']:x for e in external.values()for x in[e['source']]+e['objects']}
floor_path=R/'external-floor.json';dump(floor_path,{'admission_ready':True,'modules':external,'immutable_files':list(records.values()),'gaps':[],'root_modules':sorted(roots),'parent_floor_identity':old_plan['external_floor']})
baseline=R/'baseline-type-axiom-review.json';dump(baseline,{'expected_reports':expected,'original_returned_qualifier':original_qualifier,'legacy_affected_objects_reused':False,'qualified_packing_boundary':pin(B/'plan.json')})
runner=R/'execute_bounded.py';shutil.copyfile(D/'native-expanded8-memory-runner-20261014.py',runner);shutil.copyfile(__file__,R/'prepare.py')
mapping=R/'source-mapping.json';dump(mapping,{'scope':'Fresh compact inverse dependencies after exact packing-owner boundary; original statements and baseline audits required.','native_credit':0,'certification':False})
policy=D/'expanded8-r02-memory-policy-20261014.json'
plan={**base,'targets':targets,'external_floor':{**pin(floor_path),'admission_ready':True},'owned_import_pool':pin(pool_path),'owned_imports':[x['copy']for x in selected],
 'lean_path':[str(pool/'modules'),str(R/'project')]+base['lean_path'][2:],
 'pins':[base['lean'],pin(floor_path),pin(pool_path),pin(baseline),pin(mapping),pin(runner),pin(R/'prepare.py'),pin(policy),pin(B/'plan.json'),pin(B/'events.jsonl')]
  +original_qualifier+[r for t in targets for r in[t['source'],t['predecessor_source'],t['original_source']]]+[x['copy']for x in selected],
 'scope':'Eight fresh compact factor/error dependencies; only freshly qualified packing objects reused.'}
dump(R/'plan.json',plan)
review={'status':'SELF_REVIEWED_UNRUN','plan':pin(R/'plan.json'),'runner':pin(runner),'owned_floor':pin(pool_path),'fresh_audits':len(expected),'arguments':{'module':names[-1]},'scope':plan['scope'],'native_credit':0,'certification':False};dump(R/'review.json',review)
assert sum(x.stat().st_size for x in R.rglob('*')if x.is_file())+6*8388608+1048576+262144<134217728
print(json.dumps({'fresh_folder':R.name,'targets':len(targets),'audits':len(expected),'external_modules':len(external),'plan_sha256':review['plan']['sha256']}))
