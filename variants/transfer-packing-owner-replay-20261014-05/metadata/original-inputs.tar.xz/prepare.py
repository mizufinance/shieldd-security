"""Fresh eight-module replay; no legacy owned object is reused."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shutil
import argparse

D = Path(__file__).resolve().parent
p = argparse.ArgumentParser(); p.add_argument('--root', default='transfer-packing-owner-replay-20261014-05'); p.add_argument('--memory-profile', choices=['expanded4096','expanded8192'], default='expanded8192'); p.add_argument('--policy-file'); args = p.parse_args()
R = (D / args.root).resolve()
assert R.parent == D
assert not R.exists()
R.mkdir()
B = D / 'transfer-blst-arm-inverse-window-bfxil-bridge-20261014-03'
base = json.loads((B / 'plan.json').read_bytes())
spec = importlib.util.spec_from_file_location('guard', B / 'execute_bounded.py')
guard = importlib.util.module_from_spec(spec); spec.loader.exec_module(guard)
old_owned = json.loads(Path(base['owned_import_pool']['path']).read_bytes())
old_floor = json.loads(Path(base['external_floor']['path']).read_bytes())

def pin(path):
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, indent=2, sort_keys=True)+'\n').encode())

def raw_source(path):
    text = path.read_text(encoding='utf-8')
    if 'set_option pp.all true in' in text:
        namespace = re.search(r'^namespace (\S+)', text, re.M)[1]
        text = text.split('set_option pp.all true in', 1)[0] + 'end ' + namespace + '\n'
    assert '#check' not in text and '#print' not in text
    assert not re.search(r'\b(?:sorry|admit|axiom)\b', guard.code_only(text))
    return text

packet = D / 'native-low31-draft-20261014' / 'followup-packing-boundary-01'
modules = ['TransferNullifierModulus01', 'TransferScalarSerializationRange01',
    'TransferScalarWordPrimitives01', 'TransferBlstArmInverseWindowArithmetic01',
    'TransferBlstArmInverseWindowShift01', 'TransferBlstArmInverseWindowAlign01',
    'TransferBlstArmInverseWindowClz01', 'TransferBlstArmInverseWindowSelect01']
targets = []; roots = {'Init'}; expected = {}; dependency_graph = {}
for module in modules:
    source = packet / 'source' / 'ShielddSecurity' / (module + '.lean')
    if module == 'TransferBlstArmInverseWindowShift01':
        source = D / 'transfer-blst-arm-inverse-window-shift-20261014-03' / 'handwritten' / source.name
    text = raw_source(source)
    if module == 'TransferScalarSerializationRange01':
        # Original range/word definitions use core Nat power, unlike the
        # later WindowArithmetic declarations. Do not introduce a monoid
        # power instance into the range module's definition environment.
        assert text.count('import Mathlib.Algebra.Group.Nat.Defs\n') == 1
        text = text.replace('import Mathlib.Algebra.Group.Nat.Defs\n', '')
    namespace = re.search(r'^namespace (\S+)', text, re.M)[1]
    names = re.findall(r'^(?:def|theorem|structure) (\w+)', guard.code_only(text), re.M)
    assert names and len(names) == len(set(names))
    imports, implicit = guard.header(text)
    assert implicit
    owned_dependencies = [x.removeprefix('ShielddSecurity.') for x in imports if x.startswith('ShielddSecurity.')]
    assert all(x in modules[:modules.index(module)] for x in owned_dependencies), module
    dependency_graph[module] = owned_dependencies
    roots.update(x for x in imports if not x.startswith('ShielddSecurity.'))
    audited = text.replace('end ' + namespace, '\n'.join(
        'set_option pp.all true in\n#check @' + name + '\n#print axioms ' + name for name in names) + '\nend ' + namespace)
    handwritten = R / 'handwritten' / source.name
    project = R / 'project' / 'ShielddSecurity' / source.name
    handwritten.parent.mkdir(exist_ok=True); project.parent.mkdir(parents=True, exist_ok=True)
    handwritten.write_bytes(audited.encode()); shutil.copyfile(handwritten, project)
    audit_names = [namespace + '.' + name for name in names]
    for name in audit_names:
        assert name in old_owned['inherited_public_reports'], name
        expected[name] = old_owned['inherited_public_reports'][name]
    targets.append({'module': module, 'source': pin(project), 'predecessor_source': pin(handwritten),
                    'original_source': pin(source), 'imports': imports, 'audit_names': audit_names})

external = {}
def include(module):
    if module in external: return
    assert module in old_floor['modules'], module
    entry = old_floor['modules'][module]
    external[module] = entry
    for dependency in entry['imports']: include(dependency)
    if entry.get('implicit_Init'): include('Init')
for module in sorted(roots): include(module)
records = {}
for entry in external.values():
    for record in [entry['source']] + entry['objects']:
        key = os.path.normcase(record['path'])
        assert key not in records or records[key] == record
        records[key] = record
floor = {'kind': 'Exact live external source/object subclosure', 'admission_ready': True,
    'modules': external, 'immutable_files': list(records.values()), 'gaps': [],
    'root_modules': sorted(roots), 'parent_floor_identity': base['external_floor'],
    'scope': 'Eight-module fresh packing boundary; all live external identities retained unchanged.'}
floor_path = R / 'external-floor.json'; dump(floor_path, floor)
pool = R / 'owned-floor'
(pool / 'modules').mkdir(parents=True)
# Do not create modules/ShielddSecurity: its first-package-root would shadow
# this plan's freshly compiled project objects.
pool_path = pool / 'composition-review.json'
dump(pool_path, {'admission_ready': True, 'kernel_credit': 0, 'selected': [],
    'objects': 0, 'input_records': [], 'inherited_public_reports': {},
    'scope': 'Empty owned floor: every selected owned dependency is freshly compiled.'})
baseline_path = R / 'baseline-type-axiom-review.json'
dump(baseline_path, {'expected_reports': expected, 'legacy_objects_reused': False,
    'replayed_owned_modules': modules, 'owned_dependency_graph': dependency_graph,
    'optional_codec_not_imported': True, 'new_semantic_claims': 0,
    'qualification_requires_complete_type_and_axiom_equality': True})
larger = args.memory_profile == 'expanded8192'
policy_path = D / (args.policy_file if args.policy_file else 'expanded8-r02-memory-policy-20261014.json' if larger else 'expanded-memory-policy-20261014.json')
assert policy_path.resolve().parent == D
runner = R / 'execute_bounded.py'; shutil.copyfile(D / ('native-expanded8-memory-runner-20261014.py' if larger else 'native-expanded-memory-runner-20261014.py'), runner)
assert pin(runner)['sha256'] == ('32e3856ab841004a8485435e423cac3ae407d84da227b44750ca7ce803ceda9c' if larger else '7fc77365cf51df0a43b4ebf969b1d8890b3c217bac1e704d049504eb5477f97a')
shutil.copyfile(__file__, R / 'prepare.py')
mapping_path = R / 'source-mapping.json'
dump(mapping_path, {'scope': 'Fresh definition-owner boundary, original complete types and premises retained.',
    'exact_runtime_sha': '844389ee069e1fb2e576708842d0b389b4d9a44a',
    'targets': targets, 'legacy_owned_objects_reused': False,
    'native_credit': 0, 'certification': False})
plan = {'kind': 'Fresh narrow packing dependency replay', 'host': base['host'],
    'lean': base['lean'], 'lean_path': [str(pool/'modules'), str(R/'project')] + base['lean_path'][2:],
    'limits': base['limits'], 'pressure_limits': base['pressure_limits'],
    'external_floor': {**pin(floor_path), 'admission_ready': True}, 'owned_import_pool': pin(pool_path),
    'owned_imports': [], 'targets': targets, 'memory_profile': args.memory_profile, 'memory_policy': pin(policy_path),
    'human_memory_authorization': 'you are allowed to use way more memory',
    'scope': 'Fresh replay of every owned dependency at the changed packing boundary; no old object reuse.',
    'attempt_policy': 'Stop on first failure, retain receipts, no reset or unchanged retry.',
    'pins': [base['lean'], base['external_floor'], pin(floor_path), pin(pool_path), pin(baseline_path),
             pin(mapping_path), pin(runner), pin(R/'prepare.py'), pin(policy_path)]
        + [x for target in targets for x in [target['source'], target['predecessor_source'], target['original_source']]],
    'native_accounting': {'native_credit': 0, 'certification': False}}
plan['limits'] = dict(plan['limits']); plan['pressure_limits'] = dict(plan['pressure_limits'])
plan['limits']['heap_mib'] = 8192 if larger else 4096
plan['pressure_limits']['owned_job_memory_and_rss_bytes'] = (12 if larger else 6) * 1024**3
dump(R / 'plan.json', plan)
review = {'status': 'SELF_REVIEWED_UNRUN', 'plan': pin(R/'plan.json'), 'runner': pin(runner),
    'owned_floor': pin(pool_path), 'fresh_audits': len(expected), 'arguments': {'module': modules[-1]},
    'scope': plan['scope'], 'native_credit': 0, 'certification': False}
dump(R / 'review.json', review)
assert sum(x.stat().st_size for x in R.rglob('*') if x.is_file()) + 6*8388608 + 1048576 + 262144 < 134217728
print(json.dumps({'fresh_folder': R.name, 'targets': len(targets), 'audits': len(expected),
    'external_modules': len(external), 'external_bytes': sum(x['bytes'] for x in records.values()),
    'legacy_owned_objects_reused': False, 'plan_sha256': review['plan']['sha256']}))
